import React from "react";

const bookCategories = () => {
	return <div />;
};

export default bookCategories;
