import React from "react";
import Speaker from "./Speaker/Speaker";
const speakers = () => {
	return <div />;
};

export default speakers;
