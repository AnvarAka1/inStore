import { createContext } from "react";

const AuthModalContext = createContext();
export default AuthModalContext;
