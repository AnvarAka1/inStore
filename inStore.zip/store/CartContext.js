import { createContext } from "react";

const cartContext = createContext();
export default cartContext;
