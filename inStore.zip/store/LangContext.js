import { createContext } from "react";

const langContext = createContext();
export default langContext;
